"use strict";var KTAccountSettingsOverview={init:function(){}};KTUtil.onDOMContentLoaded((function(){KTAccountSettingsOverview.init()}));
